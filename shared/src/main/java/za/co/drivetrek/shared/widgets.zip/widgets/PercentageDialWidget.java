package za.co.drivetrek.shared.widgets;

import android.animation.AnimatorSet;
import android.animation.ObjectAnimator;
import android.content.Context;
import android.content.res.ColorStateList;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Paint.Align;
import android.graphics.Point;
import android.graphics.RectF;
import android.util.AttributeSet;
import android.view.View;

import za.co.drivetrek.shared.R;

public class PercentageDialWidget extends View {
    protected Paint dialProgressPaint;
    protected Paint dialPaint;
    protected Paint percentageTextPaint;
    protected Paint labelPaint;

    protected String descriptionText;
    protected String percentageText;

    protected float discoveryAngle;
    protected Point dialCenterPoint;
    protected int paddingSize;

    public PercentageDialWidget(Context context) {
        super(context);
        init(null, null, null, null, null);
    }

    public PercentageDialWidget(Context context, AttributeSet attrs) {
        super(context, attrs);

        TypedArray attributes = context.getTheme().obtainStyledAttributes(attrs, R.styleable.PercentageDial, 0, 0);
        ColorStateList percentageTextColor = attributes.getColorStateList(R.styleable.PercentageDial_percentageTextColor);
        ColorStateList labelTextColor = attributes.getColorStateList(R.styleable.PercentageDial_labelTextColor);
        ColorStateList dialColor = attributes.getColorStateList(R.styleable.PercentageDial_dialColor);
        ColorStateList dialProgressColor = attributes.getColorStateList(R.styleable.PercentageDial_dialProgressColor);
        String labelText = attributes.getString(R.styleable.PercentageDial_labelText);

        init(percentageTextColor, labelTextColor, dialColor, dialProgressColor, labelText);
    }

    private void init(ColorStateList percentageTextColor,
                      ColorStateList labelTextColor,
                      ColorStateList dialColor,
                      ColorStateList dialProgressColor,
                      String labelText) {
        // stuff needed to draw the dial
        dialCenterPoint = new Point();

        paddingSize = (int) getResources().getDimension(R.dimen.dial_padding);
        float selfPaymentArcWidth = getResources().getDimension(R.dimen.other_arc_width);
        float discoveryArcWidth = getResources().getDimension(R.dimen.drivetrek_arc_width);

        // the text that is displayed
        descriptionText = labelText != null ? labelText : getResources().getString(R.string.lessons_completed);
        percentageText = "0";

        percentageTextPaint = createPercentageTextPaint(percentageTextColor);
        labelPaint = createLabelTextPaint(labelTextColor);
        dialPaint = createDialPaint(dialColor, selfPaymentArcWidth);
        dialProgressPaint = createProgressDialPaint(dialProgressColor, discoveryArcWidth);
    }

    public void setDiscoveryAngle(float discoveryAngle) {
        this.discoveryAngle = discoveryAngle;
        invalidate();
    }

    private Paint createProgressDialPaint(ColorStateList color, float arcWidth) {
        Paint paint = new Paint();
        paint.setAntiAlias(true);
        paint.setColor(color != null ? color.getDefaultColor() : getResources().getColor(R.color.colorAccent));
        paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeWidth(arcWidth);
        return paint;
    }

    private Paint createDialPaint(ColorStateList color, float arcWidth) {
        Paint paint = new Paint();
        paint.setAntiAlias(true);
        paint.setColor(color != null ? color.getDefaultColor() : getResources().getColor(R.color.colorPrimaryDark));
        paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeWidth(arcWidth);
        return paint;
    }

    private Paint createLabelTextPaint(ColorStateList color) {
        Paint paint = new Paint();
        paint.setAntiAlias(true);
        paint.setColor(color != null ? color.getDefaultColor() : getResources().getColor(R.color.buttonText));
        paint.setTextSize(getResources().getDimension(R.dimen.other_text_size));
        paint.setTextAlign(Align.CENTER);
        paint.setStyle(Paint.Style.FILL);
        paint.setStrokeWidth(2);
        return paint;
    }

    private Paint createPercentageTextPaint(ColorStateList color) {
        Paint paint = new Paint();
        paint.setAntiAlias(true);
        paint.setColor(color != null ? color.getDefaultColor() : getResources().getColor(R.color.colorAccent));
        paint.setTextSize(getResources().getDimension(R.dimen.drivetrek_text_size));
        paint.setTextAlign(Align.CENTER);
        paint.setStyle(Paint.Style.FILL);
        paint.setStrokeWidth(2);
        return paint;
    }

    @Override
    protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
        setMeasuredDimension(measureWidth(widthMeasureSpec),
                measureHeight(heightMeasureSpec));
        dialCenterPoint.x = getWidth() / 2;
        dialCenterPoint.y = getHeight() / 2;
    }

    /**
     * Determines the width of this view
     *
     * @param measureSpec A measureSpec packed into an int
     * @return The width of the view, honoring constraints from measureSpec
     */
    private int measureWidth(int measureSpec) {
        int result = 0;
        int specMode = MeasureSpec.getMode(measureSpec);
        int specSize = MeasureSpec.getSize(measureSpec);

        if (specMode == MeasureSpec.EXACTLY) {
            // We were told how big to be
            result = specSize;
        } else {
            // Measure the text
            result = specSize;
            if (specMode == MeasureSpec.AT_MOST) {
                // Respect AT_MOST value if that was what is called for by
                // measureSpec
                result = Math.min(result, specSize);
            }
        }

        return result;
    }

    /**
     * Determines the height of this view
     *
     * @param measureSpec A measureSpec packed into an int
     * @return The height of the view, honoring constraints from measureSpec
     */
    private int measureHeight(int measureSpec) {
        int result = 0;
        int specMode = MeasureSpec.getMode(measureSpec);
        int specSize = MeasureSpec.getSize(measureSpec);

        if (specMode == MeasureSpec.EXACTLY) {
            result = specSize;
        } else {
            result = specSize;
            if (specMode == MeasureSpec.AT_MOST) {
                // Respect AT_MOST value if that was what is called for by
                // measureSpec
                result = Math.min(result, specSize);
            }
        }
        return result;
    }

    @Override
    protected void onDraw(Canvas canvas) {
        float height = getHeight();
        float width = getWidth();
        dialCenterPoint.x = (int) (width / 2);
        dialCenterPoint.y = (int) (height / 2);

        float ascent = (int) (percentageTextPaint.ascent() * 0.30);
        float descriptionAscent = (int) labelPaint.ascent();

        float radius = width < height ? width / 2 : height / 2;
        radius -= paddingSize;

        RectF discoveryRect = new RectF();
        discoveryRect.set(dialCenterPoint.x - radius, dialCenterPoint.y - radius,
                dialCenterPoint.x + radius, dialCenterPoint.y + radius);
        canvas.drawArc(discoveryRect, 270.0f, -360, false, dialPaint);
        canvas.drawArc(discoveryRect, 270.0f, discoveryAngle, false, dialProgressPaint);
        canvas.drawText(percentageText + "%", (float) dialCenterPoint.x,
                dialCenterPoint.y - ascent, percentageTextPaint);
        canvas.drawText(descriptionText, (float) dialCenterPoint.x,
                dialCenterPoint.y - ascent - descriptionAscent + 5, labelPaint);
        super.onDraw(canvas);
    }

    public void animateDial(int percentage) {
        discoveryAngle = 0;
        percentageText = Integer.toString(percentage);
        float targetAngle = (percentage / 100.0f) * 360;

        ObjectAnimator fadeInDialViewBackgroundRing;
        AnimatorSet dailGroupAnimationSet;
        fadeInDialViewBackgroundRing = ObjectAnimator.ofFloat(this, "discoveryAngle", targetAngle);
        dailGroupAnimationSet = new AnimatorSet();
        dailGroupAnimationSet.playTogether(fadeInDialViewBackgroundRing);
        dailGroupAnimationSet.setStartDelay(500);
        dailGroupAnimationSet.setDuration(3000);
        dailGroupAnimationSet.start();
    }
}