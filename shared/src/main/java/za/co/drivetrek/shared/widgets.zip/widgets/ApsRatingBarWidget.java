package za.co.drivetrek.shared.widgets;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.PorterDuff;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.LayerDrawable;
import android.os.Build;
import android.util.AttributeSet;
import android.util.Log;

import androidx.annotation.ColorInt;
import androidx.appcompat.widget.AppCompatRatingBar;
import androidx.core.content.ContextCompat;
import androidx.core.graphics.drawable.DrawableCompat;

import za.co.drivetrek.shared.R;

public class ApsRatingBarWidget extends AppCompatRatingBar {

    private String TAG = "ApsRatingBar";
    public ApsRatingBarWidget(Context context) {
        super(context);
    }

    public ApsRatingBarWidget(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        init(attributeSet, 0);
    }

    public ApsRatingBarWidget(Context context, AttributeSet attributeSet, int defstyleattr) {
        super(context, attributeSet, defstyleattr);
        init(attributeSet, defstyleattr);
    }

    private void init(AttributeSet attrs, int defStyleAttr) {
        setAttributes(attrs, defStyleAttr);
        setIsIndicator(true);
    }

    private void setAttributes(AttributeSet attributeSet, int defStyleAttr) {
        TypedArray attributes =
                getContext().getTheme().obtainStyledAttributes(attributeSet,
                        R.styleable.ColorStarRating, defStyleAttr, 0);
        int progressColor = attributes.getColor(R.styleable.ColorStarRating_dtk_orange,
                ContextCompat.getColor(getContext(), R.color.dtk_orange));
    }

    private void setRatingStarColor(Drawable drawable, @ColorInt int color) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            DrawableCompat.setTint(drawable, color);
        } else {
            drawable.setColorFilter(color, PorterDuff.Mode.SRC_ATOP);
        }
    }

    public void setRatingProgressColor(int resId) {
        LayerDrawable stars = (LayerDrawable) getProgressDrawable();
        setRatingStarColor(DrawableCompat.wrap(stars.getDrawable(2)),  resId);
        setRatingStarColor(DrawableCompat.wrap(stars.getDrawable(1)), resId);
    }

    public void setCustomRating(float rating, int numStars, @ColorInt int color) {
        if (numStars >= rating) {
            this.setNumStars(numStars);
            this.setRating(rating);
            setRatingProgressColor(color);
        } else {
            Log.d(TAG, "Rating is greater than number of stars");
        }
    }
}
